# Installation sur LWS — Club Culture Pétanque

## 📋 Prérequis

- Compte LWS avec accès SSH
- Node.js 18+ activé (demander au support LWS)
- Base de données (PostgreSQL ou MySQL)
- Domaine pointé vers serveur

## 🚀 Étapes installation

### 1. Connexion SSH

```bash
ssh username@lws_ip -p 22
```

### 2. Créer dossier projet

```bash
cd ~
mkdir clubculture
cd clubculture
```

### 3. Uploader fichiers

Via SFTP ou FTP :
```bash
sftp username@lws_ip
cd clubculture
put clubculture-production.zip
exit
```

Ou via SCP :
```bash
scp clubculture-production.zip username@lws_ip:~/clubculture/
```

### 4. Extraire ZIP

```bash
cd ~/clubculture
unzip clubculture-production.zip
ls -la
```

### 5. Créer dossier public

```bash
mkdir -p public
mv Club\ Culture\ Pétanque.dc.html public/
mv Club\ Culture\ Pétanque\ Deck.dc.html public/
mv logo.png public/
mv deck-stage.js public/
cp -r _ds public/
```

### 6. Installer dépendances Node.js

```bash
npm install
```

### 7. Configurer base de données (cPanel LWS)

1. Accéder à cPanel
2. Aller à "Bases de données"
3. Créer nouvelle BD : `clubculture`
4. Créer utilisateur : `clubculture`
5. Définir password complexe
6. Assigner utilisateur à BD

**Note BD access :**
- Host : localhost
- Database : clubculture
- User : clubculture
- Password : (copier from cPanel)

### 8. Configurer .env

```bash
cp .env.example .env
nano .env
```

Remplir :
```
NODE_ENV=production
PORT=3000
DB_HOST=localhost
DB_PORT=5432
DB_USER=clubculture
DB_PASSWORD=<password_from_cPanel>
DB_NAME=clubculture
```

Sauvegarder (Ctrl+X, Y, Enter)

### 9. Démarrer application

**Option A: Direct (test)**
```bash
node server.js
```

**Option B: PM2 (production - recommandé)**
```bash
npm install -g pm2
pm2 start server.js --name "clubculture"
pm2 startup
pm2 save
```

Vérifier :
```bash
pm2 status
```

### 10. Configurer domaine (cPanel)

1. Aller à "Addon Domains" ou "Domains"
2. Ajouter domaine : clubculture.mq
3. Document root : /home/username/clubculture/public
4. Créer SSL gratuit (Let's Encrypt)

### 11. Configurer Nginx/Apache (cPanel)

Si LWS utilise Nginx, ajouter cette config :

**Via cPanel → EasyApache / MultiPHP :**

```
location / {
  proxy_pass http://localhost:3000;
  proxy_http_version 1.1;
  proxy_set_header Upgrade $http_upgrade;
  proxy_set_header Connection 'upgrade';
  proxy_set_header Host $host;
  proxy_cache_bypass $http_upgrade;
}
```

### 12. Vérifier installation

```bash
curl http://localhost:3000/health
# Doit retourner : {"status":"ok"}

curl https://clubculture.mq/health
# Doit aussi retourner : {"status":"ok"}
```

## 🆘 Dépannage

### "Port 3000 already in use"
```bash
sudo lsof -i :3000
kill -9 <PID>
```

### "npm: command not found"
```bash
# Node.js non installé
# Contacter LWS pour l'activer
```

### "Cannot find module express"
```bash
npm install
npm install
```

### Domaine affiche "Connection refused"
- Vérifier firewall (port 3000 ouvert)
- Vérifier Nginx/Apache config
- Redémarrer LWS

## 📞 Support

- **LWS Support :** https://www.lws.fr/support
- **Contact club :** info@clubculture.mq

---

**Après installation :** Site accessible sur clubculture.mq ✅
