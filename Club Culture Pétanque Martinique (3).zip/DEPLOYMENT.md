# Guide de déploiement — Club Culture Pétanque

## Option 1: Vercel (Recommandé — gratuit, rapide)

### Prérequis
- Compte GitHub
- Compte Vercel (gratuit)

### Étapes

1. **Créer repo GitHub**
```bash
git init
git add Club\ Culture\ Pétanque.dc.html deck-stage.js logo.png CLAUDE.md README.md
git commit -m "Initial commit - Club Culture Pétanque"
git remote add origin https://github.com/YOUR_USERNAME/club-culture-petanque
git push -u origin main
```

2. **Déployer sur Vercel**
- Aller sur https://vercel.com/new
- Importer repo GitHub
- Vercel détecte automatiquement (pas de config nécessaire)
- Cliquer "Deploy"

3. **URL en direct:** `https://club-culture-petanque.vercel.app`

---

## Option 2: Netlify (Statique)

### Étapes

1. **Créer repo GitHub** (voir Option 1 étapes 1)

2. **Déployer sur Netlify**
- Aller sur https://app.netlify.com
- "Add new site" → "Import an existing project"
- Sélectionner repo GitHub
- Build command: (laisser vide — site statique)
- Publish directory: `.` (racine)
- Cliquer "Deploy"

3. **URL:** `https://club-culture-petanque.netlify.app`

---

## Option 3: Serveur VPS (Production avec backend)

### Prérequis
- VPS Linux (Ubuntu 22.04+)
- Node.js 18+
- PostgreSQL ou MongoDB
- Nginx/Apache

### Étapes

1. **Configurer VPS**
```bash
# SSH into server
ssh root@YOUR_SERVER_IP

# Update system
apt update && apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
apt install -y nodejs

# Install Nginx
apt install -y nginx

# Install PostgreSQL
apt install -y postgresql postgresql-contrib
```

2. **Cloner projet**
```bash
cd /var/www
git clone https://github.com/YOUR_USERNAME/club-culture-petanque
cd club-culture-petanque
```

3. **Créer backend Node.js**
```bash
npm init -y
npm install express cors dotenv pg nodemailer stripe
```

4. **server.js**
```javascript
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('.'));

const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// Routes API (voir API_ENDPOINTS.md)
app.get('/api/members', async (req, res) => {
  const result = await pool.query('SELECT * FROM members');
  res.json(result.rows);
});

app.listen(3000, () => console.log('Server on :3000'));
```

5. **PM2 (process manager)**
```bash
npm install -g pm2
pm2 start server.js --name "clubculture"
pm2 startup
pm2 save
```

6. **Nginx config**
```bash
# /etc/nginx/sites-available/clubculture
server {
    listen 80;
    server_name clubculture.mq www.clubculture.mq;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
ln -s /etc/nginx/sites-available/clubculture /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx
```

7. **SSL (Let's Encrypt)**
```bash
apt install -y certbot python3-certbot-nginx
certbot --nginx -d clubculture.mq -d www.clubculture.mq
```

8. **Base de données**
```bash
sudo -u postgres psql
CREATE DATABASE clubculture;
\c clubculture

CREATE TABLE members (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255),
  email VARCHAR(255) UNIQUE,
  phone VARCHAR(20),
  level VARCHAR(50),
  join_date DATE DEFAULT CURRENT_DATE
);

CREATE TABLE events (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255),
  date DATE,
  time TIME,
  location VARCHAR(255),
  description TEXT,
  status VARCHAR(50)
);

-- ... autres tables
```

9. **.env**
```
DATABASE_URL=postgresql://user:password@localhost/clubculture
NODE_ENV=production
STRIPE_KEY=sk_live_...
SENDGRID_KEY=SG...
```

### URL en direct
- **Domaine:** clubculture.mq
- **HTTPS:** Automatique via Let's Encrypt
- **Backend:** Node.js/Express
- **DB:** PostgreSQL

---

## Option 4: Docker (Scalable)

### Dockerfile
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY . .
RUN npm install
EXPOSE 3000
CMD ["node", "server.js"]
```

### docker-compose.yml
```yaml
version: '3.8'
services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      DATABASE_URL: postgresql://user:pass@db:5432/clubculture
  db:
    image: postgres:15
    environment:
      POSTGRES_DB: clubculture
      POSTGRES_PASSWORD: secure_password
    volumes:
      - postgres_data:/var/lib/postgresql/data
volumes:
  postgres_data:
```

### Déployer
```bash
docker-compose up -d
```

---

## Checklist avant production

- [ ] SSL/HTTPS activé
- [ ] Base de données configurée
- [ ] Variables d'environnement définies
- [ ] Authentification JWT implémentée
- [ ] Validation inputs serveur
- [ ] Rate limiting actif
- [ ] Logs centralisés (Sentry, LogRocket)
- [ ] Monitoring (UptimeRobot, DataDog)
- [ ] Backups automatiques DB
- [ ] Tests avant déploiement (`npm test`)

---

## Domaine personnalisé

1. **Acheter domaine** (Namecheap, OVH)
2. **Pointer vers serveur**
   - A record: `YOUR_SERVER_IP`
   - CNAME (www): `clubculture.mq`
3. **SSL automatique** (Let's Encrypt)

---

**Besoin d'aide?** Contacter : info@clubculture.mq
