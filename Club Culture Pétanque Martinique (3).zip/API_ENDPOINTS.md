# API Endpoints — Club Culture Pétanque

Points de terminaison pour intégrer un backend Node.js/Express.

## Authentification

### POST /api/auth/register
Inscription utilisateur

```json
{
  "email": "user@example.com",
  "password": "secure123",
  "name": "Jean Durand"
}
```

**Response:** `{ token, userId, message }`

### POST /api/auth/login
Connexion

```json
{
  "email": "user@example.com",
  "password": "secure123"
}
```

**Response:** `{ token, userId }`

---

## Membres

### GET /api/members
Récupérer tous les membres

**Response:** 
```json
[
  { "id": 1, "name": "Jean", "email": "...", "phone": "...", "level": "Avancé", "joinDate": "..." },
  ...
]
```

### POST /api/members
Ajouter un membre

```json
{
  "name": "Marie",
  "email": "marie@email.com",
  "phone": "+596...",
  "level": "Intermédiaire"
}
```

### DELETE /api/members/:id
Supprimer un membre

---

## Événements

### GET /api/events
Récupérer événements

**Response:**
```json
[
  { "id": 1, "title": "Tournoi", "date": "...", "time": "...", "location": "La Crique", "description": "...", "status": "Ouvert" },
  ...
]
```

### POST /api/events
Créer événement

```json
{
  "title": "Championnat",
  "date": "2024-12-15",
  "time": "14:00",
  "location": "Fort-de-France",
  "description": "Compétition officielle"
}
```

### DELETE /api/events/:id
Supprimer événement

### POST /api/events/:id/register
Inscrire utilisateur

```json
{
  "userId": 1
}
```

---

## Boutique

### GET /api/products
Récupérer produits

**Response:**
```json
[
  { "id": 1, "name": "Tenue", "description": "Polo rouge", "price": 35.00 },
  ...
]
```

### POST /api/products
Ajouter produit (admin)

```json
{
  "name": "Boules",
  "description": "Set de 3",
  "price": 120.00
}
```

### DELETE /api/products/:id
Supprimer produit

---

## Panier & Paiements

### POST /api/cart
Ajouter au panier

```json
{
  "userId": 1,
  "productId": 2,
  "quantity": 1
}
```

### POST /api/checkout
Traiter paiement (Stripe)

```json
{
  "userId": 1,
  "items": [{ "productId": 1, "quantity": 1 }],
  "token": "stripe_token_...",
  "amount": 155.00
}
```

**Response:** `{ orderId, status, message }`

---

## Commentaires

### GET /api/comments
Récupérer commentaires (approuvés)

**Query:** `?eventId=1`

### POST /api/comments
Soumettre commentaire (utilisateur)

```json
{
  "userId": 1,
  "eventId": 1,
  "text": "Super tournoi !",
  "status": "pending"
}
```

### GET /api/admin/comments/pending
Récupérer commentaires en attente (admin)

### PATCH /api/admin/comments/:id
Approuver/rejeter (admin)

```json
{
  "status": "approved"
}
```

---

## Paramètres Club

### GET /api/settings
Récupérer paramètres

**Response:**
```json
{
  "clubName": "Club Culture Pétanque",
  "email": "info@clubculture.mq",
  "phone": "+596...",
  "address": "La Crique, Trinité",
  "facebook": "https://facebook.com/...",
  "whatsapp": "https://wa.me/..."
}
```

### PATCH /api/admin/settings
Modifier paramètres (admin)

```json
{
  "clubName": "...",
  "email": "...",
  ...
}
```

---

## Emails

### POST /api/email/confirmation
Envoyer confirmation inscription

```json
{
  "to": "user@example.com",
  "name": "Jean"
}
```

### POST /api/email/event-reminder
Rappel événement

```json
{
  "to": "user@example.com",
  "eventTitle": "Tournoi du mois",
  "eventDate": "2024-11-15"
}
```

---

## Exemple Node.js/Express

```javascript
// server.js
const express = require('express');
const app = express();

app.use(express.json());

// CORS
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  next();
});

// Membres
app.get('/api/members', (req, res) => {
  // Récupérer de la DB
  res.json([...]);
});

app.post('/api/members', (req, res) => {
  // Insérer en DB
  res.json({ id: 3, ...req.body });
});

// ... autres routes

app.listen(3000, () => console.log('Server running on :3000'));
```

---

**À ajouter :** Authentification JWT, validation inputs, logs, rate limiting
