# Déploiement Local — Club Culture Pétanque

## Installation sur votre ordinateur

### 1. Prérequis

- Node.js 18+ : https://nodejs.org/
- Git (optionnel)

### 2. Extraire le dossier

Dossier `clubculture-production` sur votre ordinateur

### 3. Ouvrir terminal/cmd

**Windows:** Cmd ou PowerShell
**Mac/Linux:** Terminal

```bash
cd /chemin/vers/clubculture-production
```

### 4. Installer dépendances

```bash
npm install
```

### 5. Configurer .env (optionnel pour local)

```bash
cp .env.example .env
```

Ou créer `.env`:
```
NODE_ENV=development
PORT=3000
```

### 6. Démarrer serveur

```bash
npm start
```

Vous verrez :
```
Server running on port 3000
```

### 7. Accéder au site

**Ouvrir navigateur:**
```
http://localhost:3000
```

### 8. Application web

- Accueil, Événements, Boutique, Membres, Admin — tous fonctionnels
- Données stockées en mémoire (réinitialisées au redémarrage)

### 9. Arrêter serveur

**Ctrl + C** dans le terminal

---

**Prêt pour développement local!**
