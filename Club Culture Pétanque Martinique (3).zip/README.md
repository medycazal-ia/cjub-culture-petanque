# Club Culture Pétanque — Application Web

Plateforme web complète pour la gestion d'un club de pétanque en Martinique.

## 🚀 Démarrage rapide

1. Ouvrir `Club Culture Pétanque.dc.html` dans un navigateur moderne
2. Naviguer via la barre de menu (Accueil, Événements, Boutique, Membres, Admin)
3. Tester toutes les fonctionnalités

## 📋 Fonctionnalités

### Accueil
- Logo animé avec pulse
- Présentation du club
- 6 cartes de modules
- CTA vers boutique et admin

### Événements & Tournois
- Liste événements avec statut
- Inscription directe
- Lien réservations boutique

### Boutique
- 3 produits exemple (tenue, boules, casquette)
- Panier dynamique
- Total prix calculé
- Checkout simulé

### Gestion des Membres
- Formulaire inscription (nom, email, téléphone, niveau)
- Tableau annuaire (tous les membres)
- Niveaux : Débutant → Compétiteur

### Administration (4 onglets)

#### Événements
- Créer nouvel événement (titre, date, heure, lieu, description)
- Table événements existants
- Supprimer événement

#### Produits
- Ajouter produit (nom, description, prix)
- Table produits existants
- Supprimer produit

#### Commentaires
- Commentaires en attente (avec boutons Approuver/Rejeter)
- Commentaires approuvés (avec badge ✓)
- Modération complète

#### Paramètres
- Nom du club
- Email & téléphone
- Adresse
- Liens Facebook & WhatsApp

## 🎨 Design

- **Palette:** Rouge #c41e3a (logo), blanc, gris
- **Typographie:** Serif (titres), sans-serif (corps)
- **Animations:** Pulse logo, fade-in sections, hover cards
- **Responsive:** Desktop optimisé (mobile possible avec ajustements CSS)

## 💾 Données

Actuellement stockées en **memory** (disparaissent au refresh). Pour production :

```javascript
// localStorage simple
localStorage.setItem('clubData', JSON.stringify(this.state));

// Ou API backend
fetch('/api/save', { method: 'POST', body: JSON.stringify(this.state) });
```

## 🔐 Sécurité

- [ ] Pas de connexion utilisateur actuellement
- [ ] Admin non protégé (ajouter authentification)
- [ ] Paiements simulés (ajouter Stripe/PayPal)
- [ ] Inputs validés côté client (ajouter serveur)

## 📦 Déploiement

Voir `CLAUDE.md` pour instructions complètes.

**Rapide (statique):**
```bash
# Vercel
vercel
# Netlify
netlify deploy
```

**Production (avec backend):**
```bash
# Node.js + Express
node server.js
# Ou Docker
docker build -t clubculture .
```

## 🛠️ Technologies

- HTML5, CSS3, JavaScript (vanilla)
- Design Components (.dc.html)
- Design System Classical
- Pas de dépendances npm

## 📞 Support

Contacter : info@clubculture.mq

---

**Version:** 1.0 MVP  
**Dernière mise à jour:** Octobre 2026
