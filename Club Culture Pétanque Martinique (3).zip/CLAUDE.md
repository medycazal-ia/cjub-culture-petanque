# Club Culture Pétanque — Site Web Complet

## Vue d'ensemble

Site web interactif pour le Club Culture Pétanque (La Crique, Trinité, Martinique).

**Technologie:** Design Components (`.dc.html`) — HTML/CSS/JavaScript, pas de dépendances externes.

**Fonctionnalités:**
- Gestion des membres (inscription, annuaire)
- Événements & tournois (création, inscription, résultats)
- Boutique en ligne (produits, panier, paiement simulé)
- Modération de commentaires (approbation/rejet par admins)
- Panneau d'administration (création/suppression de contenu)
- Réseaux sociaux (Facebook, WhatsApp intégrés)
- Persistance de données en localStorage

## Structure du projet

```
Club Culture Pétanque/
├── Club Culture Pétanque.dc.html    (application web principale)
├── Club Culture Pétanque Deck.dc.html (présentation 10 slides)
├── logo.png                          (logo du club rouge/blanc)
├── deck-stage.js                     (composant slide deck)
├── CLAUDE.md                         (cette documentation)
└── _ds/                              (design system Classical)
    └── classical-e77c5141.../
```

## Fichiers principaux

### Club Culture Pétanque.dc.html

Application web fonctionnelle avec 5 sections :

1. **Accueil** — Présentation du club, héros animé, CTA
2. **Événements** — Liste événements, inscription, détails
3. **Boutique** — Produits, panier, checkout
4. **Membres** — Inscription formulaire, annuaire tableau
5. **Admin** — 4 onglets :
   - Événements : créer/supprimer
   - Produits : ajouter/supprimer
   - Commentaires : modérer (approuver/rejeter)
   - Paramètres : infos club, réseaux sociaux

**État:** Toutes les sections navigables. Données stockées en memory (persistance localStorage possible).

### Club Culture Pétanque Deck.dc.html

Présentation 10 slides — deck-stage, speaker notes, exportable PPTX.

## Déploiement pour production

### Exigences serveur

1. **Serveur statique** (nginx, Apache, Node.js/Express)
2. **Base de données** (optionnel — actuellement en-mémoire)
3. **API backend** (pour persistance/traitement de paiements)

### Étapes déploiement

#### 1. Base de données

Migrer du localStorage vers une base persistante :

```javascript
// Exemple : Firebase, Supabase, ou API Node.js
// Ajouter dans Component.componentDidMount():
fetch('/api/members').then(r => r.json()).then(members => {
  this.setState({ members });
});
```

#### 2. Paiements

Remplacer le checkout simulé par Stripe/PayPal :

```javascript
checkout = async () => {
  const total = this.state.cartItems.reduce(...);
  const response = await fetch('/api/charge', {
    method: 'POST',
    body: JSON.stringify({ amount: total })
  });
  // Traiter réponse
};
```

#### 3. Emails

Ajouter notifications (Nodemailer, SendGrid) :

```javascript
// Confirmation inscription, événement, panier
fetch('/api/send-email', {
  method: 'POST',
  body: JSON.stringify({ to, subject, html })
});
```

#### 4. Modération commentaires

Ajouter formulaire utilisateur pour soumettre commentaires :

```html
<div class="form-group">
  <label>Votre commentaire</label>
  <textarea value="{{ userComment }}" onChange="..."></textarea>
  <button onClick="{{ submitComment() }}">Envoyer</button>
</div>
```

#### 5. Hébergement

Options :
- **Vercel** (redéploiement automatique GitHub)
- **Netlify** (static + serverless functions)
- **AWS/GCP** (plus de contrôle)
- **VPS Linux** (hébergement classique)

Pour Vercel/Netlify :
```bash
git add Club\ Culture\ Pétanque.dc.html deck-stage.js logo.png CLAUDE.md
git commit -m "Initial commit"
git push origin main
```

## Améliorations futures

### Phase 1 (Court terme)
- [ ] Connexion utilisateur (login/register)
- [ ] Profils membres (avatar, historique tournois)
- [ ] Paiements réels (Stripe intégré)
- [ ] Notifications email

### Phase 2 (Moyen terme)
- [ ] Classements/statistiques joueurs
- [ ] Galerie photos événements
- [ ] Forum discussion
- [ ] Mobile app native

### Phase 3 (Long terme)
- [ ] IA recommandation matchs
- [ ] Streaming live tournois
- [ ] Intégration GPS lieux de jeu

## Support & Contact

- **Email:** info@clubculture.mq
- **Téléphone:** +596 696 12 34 56
- **Adresse:** La Crique, Trinité, Martinique

---

**Dernière mise à jour:** Octobre 2026
**Responsable technique:** Webmaster Club Culture Pétanque
